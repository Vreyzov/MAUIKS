﻿using HabitTrackerApp.Views;

namespace HabitTrackerApp
{
    public partial class AppShell : Shell
    {
        public AppShell()
        {
            InitializeComponent();
        }
    }
}
